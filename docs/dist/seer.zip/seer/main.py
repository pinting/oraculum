from __future__ import annotations

import argparse
import sys

import core
from core import EOS_ID, VOCABULARY_PATH
from src import DraftKind, Engine, debug

ROUTE_LIMIT: int = 100

# What `narrow` must keep on offer even though no lattice head spells it: the
# separators a constant is reached through, the terminator, the brackets of a
# nested WHERE predicate, and the characters a literal opens with. A literal is
# an expression head, so narrowing would otherwise leave nothing to type, and
# the terminator carries its own leading whitespace so it is one too.
SEPARATORS: tuple[str, ...] = (
    ".", " ", "\t", ",", ";", "(", ")", "'", "-",
) + tuple("0123456789")

def printable(token: str) -> bool:
    """Whether a token can be shown in the route list and typed back.

    Control characters would corrupt the line, and a multi-character run of
    whitespace is indistinguishable from any other once printed.
    """

    if len(token) != 1 and token.isspace():
        return False

    return not any(ord(c) < 32 or ord(c) == 127 for c in token)

def narrow(engine: Engine, routes: list[str]) -> tuple[list[str], bool]:
    """Drop the routes that no live lattice head is spelling towards.

    An `Expression` head offers most of the vocabulary, so once the route list
    runs past `ROUTE_LIMIT` the keywords and names among it are buried. The
    tokens worth showing are the ones that start what a lattice head still has
    left to match.

    Returns the surviving routes and whether anything was dropped, so the
    caller can say the list is not the whole of it.
    """

    constants: list[str] = [
        head.payload.draft.value[len(head.matched):]
        for head in engine.heads
        if head.payload.draft.kind is DraftKind.LATTICE
    ]

    constants = [constant for constant in constants if constant]

    constants.extend(SEPARATORS)

    narrowed: list[str] = [
        token
        for token in routes
        if any(constant.startswith(token) for constant in constants)
    ]

    if not narrowed or len(narrowed) == len(routes):
        return routes, False

    return narrowed, True

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Walk the seer SQL syntax graph interactively or with a model.",
    )

    parser.add_argument(
        "--live",
        action="store_true",
        help="run in model-driven live mode",
    )
    parser.add_argument(
        "--vocabulary",
        default=VOCABULARY_PATH,
        help="tiktoken vocabulary file",
    )
    parser.add_argument(
        "--eos-id",
        type=int,
        default=EOS_ID,
        help="end of sequence token id",
    )
    parser.add_argument(
        "--threads",
        type=int,
        default=1,
        help="kernel worker threads",
    )
    parser.add_argument(
        "--schema",
        default=None,
        help="path to a .sql schema, defaults to schema.sql",
    )
    parser.add_argument(
        "--no-debug",
        dest="debug",
        action="store_false",
        help="do not print the resolver state after each modifying operation",
    )

    # -- live mode --------------------------------------------------------

    parser.add_argument(
        "--model",
        default="../models/gemma-3-4b-it-Q8_0.gguf",
        help="path to the GGUF model",
    )
    parser.add_argument(
        "--model-threads",
        type=int,
        default=4,
        help="llama.cpp compute threads",
    )
    parser.add_argument(
        "--prompt",
        default="Generate an SQL SELECT request to get the emails of users!",
        help="instruction appended to the schema",
    )
    parser.add_argument("--temp", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)

    return parser.parse_args(argv)

def use_schema(path: str | None) -> bool:
    """Point `core` at the schema `--schema` names, or at `schema.sql`."""

    try:
        core.set_schema(core.SCHEMA if path is None else core.load_schema(path))
    except OSError as error:
        print(f"Failed to load schema: {error}", file=sys.stderr)

        return False

    return True

def run_interactive(args: argparse.Namespace) -> int:
    if not use_schema(args.schema):
        return 1

    try:
        raw_vocabulary: bytes = core.load_vocabulary(args.vocabulary)
    except OSError as error:
        print(f"Failed to load vocabulary: {error}", file=sys.stderr)

        return 1

    if args.threads > 1:
        print(f"Driving the head pool on {args.threads} kernel workers")

    try:
        engine: Engine = core.init_engine(
            raw_vocabulary,
            args.eos_id,
            core.get_schema(),
            args.threads,
        )
    except RuntimeError as error:
        print(f"Failed to initialize engine: {error}", file=sys.stderr)

        return 1

    try:
        while True:
            route_ids: list[int] = engine.routes().tolist()

            if not route_ids:
                break

            switch: dict[str, int] = {}

            for token_id in route_ids:
                token: str | None = engine.get_token(token_id)

                if token is not None:
                    switch[token] = token_id

            routes: list[str] = sorted(token for token in switch if printable(token))
            narrowed: bool = False

            if len(switch) > ROUTE_LIMIT:
                routes, narrowed = narrow(engine, routes)

            shown: list[str] = routes[:ROUTE_LIMIT]
            more: bool = narrowed or len(routes) > len(shown)

            print(
                "Routes: "
                + ", ".join(f"`{token}`" for token in shown)
                + (", ..." if more else " ")
            )

            while True:
                try:
                    line: str = input("> ")
                except EOFError:
                    return 0

                if not line:
                    continue

                token_id = switch.get(line)

                if token_id is None:
                    print("Non-existent token!")

                    continue

                engine.feed(token_id)

                break

            print(f"Matched: `{engine.matched()}`")

            if engine.is_completed():
                break
    finally:
        core.shutdown()

    return 0

def run_live(args: argparse.Namespace) -> int:
    from processor import LogitsProcessor
    from vocabulary import serialize_vocabulary

    if not use_schema(args.schema):
        return 1

    try:
        from llama_cpp import Llama, LogitsProcessorList
    except ImportError:
        print("llama-cpp-python is not installed; run `make live`", file=sys.stderr)

        return 1

    print(f"Loading model from {args.model}...")

    try:
        model = Llama(
            model_path=args.model,
            n_ctx=4096,
            n_threads=args.model_threads,
            n_gpu_layers=999,
            verbose=False,
        )
    except (OSError, ValueError) as error:
        print(f"Failed to load model: {error}", file=sys.stderr)

        return 1

    print("Model loaded successfully!")

    raw_vocabulary: str = serialize_vocabulary(model)
    raw_vocabulary_bytes: bytes = raw_vocabulary.encode("utf-8")

    if args.threads > 1:
        print(f"Driving the head pool on {args.threads} kernel workers")

    try:
        engine: Engine = core.init_engine(
            raw_vocabulary_bytes,
            args.eos_id,
            core.get_schema(),
            args.threads,
        )
    except RuntimeError as error:
        print(f"Failed to initialize engine: {error}", file=sys.stderr)

        return 1

    with open(args.vocabulary, "w", encoding="utf-8") as handle:
        handle.write(raw_vocabulary)

    print("Vocabulary saved successfully!")

    vocab_size: int = model.n_vocab()
    processor: LogitsProcessor = LogitsProcessor(vocab_size)

    prompt: str = f"{core.get_schema()}\n\n{args.prompt}"
    prompt_tokens: list[int] = model.tokenize(prompt.encode("utf-8"))

    print("Generating response...\n")

    try:
        for token_id in model.generate(
            prompt_tokens,
            top_p=args.top_p,
            temp=args.temp,
            logits_processor=LogitsProcessorList([processor]),
        ):
            token: bytes = model.detokenize([token_id])

            print(token_id, token)

            if len(token) == 0:
                break

            result: int = processor.feed(token_id)

            if result != 0:
                break

            # The statement is finished before the route set empties out, so
            # stopping here keeps the model from sampling past the terminator.
            if processor.is_completed():
                break
    finally:
        core.shutdown()

    print(f"\nMatched: `{engine.matched()}`")

    return 0

def main(argv: list[str] | None = None) -> int:
    args: argparse.Namespace = parse_args(argv)

    if args.debug:
        debug.enable()

    if args.live:
        return run_live(args)

    return run_interactive(args)

if __name__ == "__main__":
    raise SystemExit(main())
